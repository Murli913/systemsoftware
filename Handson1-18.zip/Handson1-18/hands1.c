#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
int main(){
	int a = symlink("dest.txt"," destSL");
	if(a<0)
		{perror("failed"); return 1;}

		int b = link("dest.txt", "destHL");
		if(b<0)
		{perror("failed");return 1;}

		int c = mknod("destFIFO", S_IFIFO,0);

		if(c<0)
			perror("failed");
		return 0;

	
}

