#include<stdio.h>
#include<fcntl.h>
#include<stdbool.h>

void main() {
  int b = 0;
  FILE* file2;
  while (true) {
    if(b<5) {
      char buffer[32];
      snprintf(buffer, sizeof(char) * 32, "file2%i.txt", b);
      file2 = fopen(buffer, "wb");
      fclose(file2);
      b++;
    }
  }
}
