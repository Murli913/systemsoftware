#include<stdio.h>
#include<fcntl.h>

void main() {
  char* file_name="temp.txt";
  mode_t mode=S_IRUSR;
  int fd1;
  if((fd1=creat(file_name, mode))<0)
    perror("Error is coming while creation of file!");
  else
    printf("done Created File Successfully! %d", fd1);
}
