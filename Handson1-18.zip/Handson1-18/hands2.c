#include<stdio.h>

void main() {
  while(1);
}
