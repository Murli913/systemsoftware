#include<unistd.h>
#include<stdio.h>
#include<fcntl.h>
#include<errno.h>
#include<string.h>

void main() {
  int fd1=open("temp1.txt", O_RDWR | O_CREAT, 0777);

  if(fd1 == -1) {
    printf("Error %d\n", errno);
    perror("Programs");
  }
  printf("fd1=%d \n", fd1);
  char* str="This is a testing";
  int wr=write(fd1, str, strlen(str)+1);
  printf("Status of writing in the file : %d\n", wr);
  close(fd1);
  fd=open("temp1.txt", O_RDWR);
  char str2[80];
  read(fd1, str2, 80);
  printf("Read = %s\n", str2);
  close(fd1);
}

