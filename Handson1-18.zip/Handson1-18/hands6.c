 #include<unistd.h>
#include<stdio.h>
#include<fcntl.h>

int main(void){
int fd1;
char buf[80];

fd1= open("newfile", O_WRONLY | O_CREAT);
read(0,buf,sizeof(buf));
write(1, buf, sizeof(buf));
printf("%s\n", buf);
}
